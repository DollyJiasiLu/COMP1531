External Libraries:

beautifulsoup4==4.6.0
certifi==2017.7.27.1
chardet==3.0.4
click==6.7
Flask==0.12.2
Flask-Login==0.4.0
idna==2.6
itsdangerous==0.24
Jinja2==2.9.6
MarkupSafe==1.0
pyenchant==1.6.11
requests==2.18.4
selenium==3.5.0
splinter==0.7.6
urllib3==1.22
Werkzeug==0.12.2


To run the program run:
python3 run.py
and visit:

http://127.0.0.1:8004

To run tests type:
python3 tests.py
